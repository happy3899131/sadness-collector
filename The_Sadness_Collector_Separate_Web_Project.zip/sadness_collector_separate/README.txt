THE SADNESS COLLECTOR — SEPARATE WEB PROJECT

Files:
- index.html  -> page structure
- style.css   -> design, responsive layout, navigation buttons, animations
- script.js   -> scene switching, keyboard controls, swipe controls, progress, fullscreen
- assets/     -> comic artwork

Navigation update:
- Next/Previous controls are now small vertical arrow buttons outside the comic artwork.
- Desktop: buttons sit just outside the left/right edges.
- Mobile: buttons become smaller and remain outside the artwork as much as the screen allows.
- The large START READING / NEXT SCENE label is hidden so it cannot cover story content.

Open index.html in a browser. Keep the assets folder beside it.
