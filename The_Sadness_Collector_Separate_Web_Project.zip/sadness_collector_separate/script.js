'use strict';

const storyScenes = [
  { src: 'assets/scene-01.jpg', title: 'The House After Dark', description: 'Some nights, the house feels full of things nobody knows how to say.', motion: 'motion-right', alt: 'Comic page: the house at night, Rica in her bedroom, and the figure known as the Big Lady.' },
  { src: 'assets/scene-02.jpg', title: 'The Warning', description: 'Rica listens as her father explains the story behind the house.', motion: 'motion-left', alt: 'Comic page: Rica talks with her father and learns about the Big Lady.' },
  { src: 'assets/scene-03.jpg', title: 'A Fear Takes Root', description: 'A story told often enough can start to feel close enough to touch.', motion: 'motion-up', alt: 'Comic page: Rica tries to understand her father’s warning and stays in her room.' },
  { src: 'assets/scene-04.jpg', title: 'Stories in the Shadows', description: 'Rica holds on to the story, even when she is alone.', motion: 'motion-zoom', alt: 'Comic page: Rica thinks about the Big Lady while reading and remembering the warning.' },
  { src: 'assets/scene-05.jpg', title: 'A Father’s Warning', description: 'The kitchen is quiet, but the warning stays with them.', motion: 'motion-left', alt: 'Comic page: Rica and her father speak about the Big Lady and the kitchen.' },
  { src: 'assets/scene-06.jpg', title: 'Sounds in the Night', description: 'A strange noise draws Rica toward the doorway.', motion: 'motion-right', alt: 'Comic page: sounds from downstairs lead Rica to look toward the kitchen.' },
  { src: 'assets/scene-07.jpg', title: 'The Visitor', description: 'The story from the warning seems to step out of the shadows.', motion: 'motion-tension', alt: 'Comic page: a frightening figure appears near the kitchen while Rica watches.' },
  { src: 'assets/scene-08.jpg', title: 'The Broken Quiet', description: 'The night grows louder, and Rica sees her father differently.', motion: 'motion-tension', alt: 'Comic page: Rica finds her father in the kitchen during a frightening moment.' },
  { src: 'assets/scene-09.jpg', title: 'What the Story Hides', description: 'Fear gives way to a difficult conversation between father and daughter.', motion: 'motion-zoom', alt: 'Comic page: Rica and her father speak after the frightening events in the kitchen.' },
  { src: 'assets/scene-10.jpg', title: 'The Last Warning', description: 'The story reaches its final quiet moments.', motion: 'motion-up', alt: 'Comic page: Rica stays beside her father as the night settles.' }
];

const cover = {
  src: 'assets/cover.jpg',
  title: 'A story told in shadows.',
  description: 'An interactive reading experience. Start the comic when you are ready.',
  motion: 'motion-cover',
  alt: 'The Sadness Collector comic cover, with Group 1 members listed on the left and the cover illustration on the right.'
};
const ending = {
  src: 'assets/end.jpg',
  title: 'The End',
  description: 'Thank you for reading The Sadness Collector.',
  motion: 'motion-still',
  alt: 'A plain beige comic page displaying the words The End.'
};

const comicImage = document.getElementById('comicImage');
const artFrame = document.getElementById('artFrame');
const phaseLabel = document.getElementById('phaseLabel');
const sceneTitle = document.getElementById('sceneTitle');
const sceneDescription = document.getElementById('sceneDescription');
const sceneCount = document.getElementById('sceneCount');
const pageChip = document.getElementById('pageChip');
const previousBtn = document.getElementById('previousBtn');
const nextBtn = document.getElementById('nextBtn');
const nextLabel = document.getElementById('nextLabel');
const progressFill = document.getElementById('progressFill');
const progressBar = document.getElementById('progressBar');
const progressStart = document.getElementById('progressStart');
const progressEnd = document.getElementById('progressEnd');
const fullscreenBtn = document.getElementById('fullscreenBtn');
const comicStage = document.getElementById('comicStage');

// -1 means cover; 0–9 are story pages; 10 is the ending page.
let currentIndex = -1;
let touchStartX = null;

function getCurrentPage() {
  if (currentIndex < 0) return cover;
  if (currentIndex >= storyScenes.length) return ending;
  return storyScenes[currentIndex];
}

function renderPage(direction = 1) {
  const isCover = currentIndex < 0;
  const isEnding = currentIndex >= storyScenes.length;
  const page = getCurrentPage();

  comicImage.src = page.src;
  comicImage.alt = page.alt;
  comicImage.className = page.motion;

  // Restart the entrance animation every time a scene changes.
  artFrame.classList.remove('is-entering');
  void artFrame.offsetWidth;
  artFrame.classList.add('is-entering');
  artFrame.dataset.direction = direction > 0 ? 'forward' : 'backward';

  phaseLabel.textContent = isCover ? 'COVER' : isEnding ? 'FINALE' : `SCENE ${String(currentIndex + 1).padStart(2, '0')}`;
  sceneTitle.textContent = page.title;
  sceneDescription.textContent = page.description;
  pageChip.textContent = isCover ? 'THE COVER' : isEnding ? 'THE END' : `SCENE ${String(currentIndex + 1).padStart(2, '0')}`;
  previousBtn.hidden = isCover;

  if (isCover) {
    sceneCount.innerHTML = 'COVER <span>/ 10</span>';
    nextLabel.textContent = 'START READING';
    nextBtn.setAttribute('aria-label', 'Start reading the comic');
    progressFill.style.width = '0%';
    progressBar.setAttribute('aria-valuenow', '0');
    progressStart.textContent = 'READY?';
    progressEnd.textContent = '10 SCENES';
  } else if (isEnding) {
    sceneCount.innerHTML = 'FINALE <span>/ 10</span>';
    nextLabel.textContent = 'READ AGAIN';
    nextBtn.setAttribute('aria-label', 'Read the comic again');
    progressFill.style.width = '100%';
    progressBar.setAttribute('aria-valuenow', '100');
    progressStart.textContent = 'COMPLETE';
    progressEnd.textContent = '100%';
  } else {
    const progress = Math.round(((currentIndex + 1) / storyScenes.length) * 100);
    sceneCount.innerHTML = `${String(currentIndex + 1).padStart(2, '0')} <span>/ ${storyScenes.length}</span>`;
    nextLabel.textContent = currentIndex === storyScenes.length - 1 ? 'VIEW THE END' : 'NEXT SCENE';
    nextBtn.setAttribute('aria-label', currentIndex === storyScenes.length - 1 ? 'View the ending' : 'Go to the next scene');
    progressFill.style.width = `${progress}%`;
    progressBar.setAttribute('aria-valuenow', String(progress));
    progressStart.textContent = `SCENE ${String(currentIndex + 1).padStart(2, '0')}`;
    progressEnd.textContent = `${progress}%`;
  }

  preloadNearbyPages();
}

function preloadNearbyPages() {
  const nearby = [];
  if (currentIndex === -1) nearby.push(storyScenes[0]);
  else if (currentIndex < storyScenes.length) {
    if (currentIndex + 1 < storyScenes.length) nearby.push(storyScenes[currentIndex + 1]);
    if (currentIndex > 0) nearby.push(storyScenes[currentIndex - 1]);
    if (currentIndex === storyScenes.length - 1) nearby.push(ending);
  } else nearby.push(cover);
  nearby.forEach((page) => {
    const img = new Image();
    img.src = page.src;
  });
}

function nextPage() {
  if (currentIndex >= storyScenes.length) currentIndex = -1;
  else currentIndex += 1;
  renderPage(1);
}

function previousPage() {
  if (currentIndex > -1) currentIndex -= 1;
  renderPage(-1);
}

nextBtn.addEventListener('click', nextPage);
previousBtn.addEventListener('click', previousPage);

// Keyboard navigation: Right/Space advances; Left goes back.
document.addEventListener('keydown', (event) => {
  const target = event.target;
  const isTyping = target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName));
  if (isTyping || event.altKey || event.ctrlKey || event.metaKey) return;
  if (event.key === 'ArrowRight' || event.key === ' ') {
    if (event.key === ' ') event.preventDefault();
    nextPage();
  } else if (event.key === 'ArrowLeft') {
    previousPage();
  }
});

// Swipe on the comic artwork to turn pages on touchscreens.
comicImage.addEventListener('touchstart', (event) => {
  touchStartX = event.changedTouches[0].clientX;
}, { passive: true });
comicImage.addEventListener('touchend', (event) => {
  if (touchStartX === null) return;
  const delta = event.changedTouches[0].clientX - touchStartX;
  if (Math.abs(delta) > 55) {
    if (delta < 0) nextPage();
    else previousPage();
  }
  touchStartX = null;
}, { passive: true });

fullscreenBtn.addEventListener('click', async () => {
  try {
    if (!document.fullscreenElement) {
      if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
    } else if (document.exitFullscreen) {
      await document.exitFullscreen();
    }
  } catch (error) {
    // Fullscreen may be blocked by a browser or by opening the file locally; the comic remains usable.
    fullscreenBtn.title = 'Fullscreen is not available in this browser view.';
  }
});

document.addEventListener('fullscreenchange', () => {
  const active = Boolean(document.fullscreenElement);
  fullscreenBtn.setAttribute('aria-label', active ? 'Exit fullscreen' : 'Toggle fullscreen');
  fullscreenBtn.querySelector('.fullscreen-label').textContent = active ? 'EXIT FULLSCREEN' : 'FULLSCREEN';
});

renderPage();
